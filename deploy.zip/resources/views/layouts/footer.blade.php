<footer>
    <div class="container">
        <p style="text-align: center">This is copyright to Sharesquare team</p>
    </div>
</footer>
