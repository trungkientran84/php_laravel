<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MyPostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function publicPost(Request $request)
    {

        $posts =  searchPost(Auth::id(), null, $request->search);
        return view('user.post-list', compact('posts'));
    }

    public function pendingPost(Request $request)
    {
        $posts =  searchPost(Auth::id(), 'PENDING', $request->search);

        return $posts;
        return view('user.post-list', compact('posts'));
    }

    public function closedPost(Request $request)
    {
        $posts =  searchPost(Auth::id(), 'CLOSED', $request->search);
        return $posts;
        return view('user.post-list', compact('posts'));
    }

    public function draftPost(Request $request)
    {
        $posts =  searchPost(Auth::id(), 'DRAFT', $request->search);
        return view('user.post-list', compact('posts'));
    }

    public function favoritePost(Request $request)
    {
        $posts = searchPost(null, null, $request->search, Auth::id());

        return view('user.post-list', compact('posts'));
    }
}
